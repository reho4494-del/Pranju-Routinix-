package com.pranju.routinix

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.pranju.routinix.data.local.RoutinixDatabase
import com.pranju.routinix.data.repository.RoutineRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class RoutinixApp : Application() {
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { RoutinixDatabase.getDatabase(this, applicationScope) }
    val repository by lazy {
        RoutineRepository(
            database.routineDao(),
            database.logDao(),
            database.goalDao(),
            database.blockedAppDao(),
            database.parentalDao()
        )
    }

    override fun onCreate() {
        super.onCreate()
        com.pranju.routinix.ui.language.LanguageManager.init(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Routine Reminders Channel
            val reminderChannel = NotificationChannel(
                CHANNEL_ROUTINE_REMINDERS,
                "Routine Schedule Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts you when routine tasks begin and end"
                enableVibration(true)
            }

            // Focus Lock Mode Channel
            val focusChannel = NotificationChannel(
                CHANNEL_FOCUS_LOCK,
                "Monk Focus & App Blocker",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows ongoing focus lock status and blocked distractions"
                setShowBadge(false)
            }

            notificationManager.createNotificationChannel(reminderChannel)
            notificationManager.createNotificationChannel(focusChannel)
        }
    }

    companion object {
        const val CHANNEL_ROUTINE_REMINDERS = "routinix_reminders_channel"
        const val CHANNEL_FOCUS_LOCK = "routinix_focus_lock_channel"
    }
}
