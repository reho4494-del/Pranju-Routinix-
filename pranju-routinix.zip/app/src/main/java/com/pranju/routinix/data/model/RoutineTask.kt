package com.pranju.routinix.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routine_tasks")
data class RoutineTask(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String, // "Deep Work", "Study", "Exercise", "Reading", "Health", "Social Detox", "Creative"
    val startMinute: Int, // e.g. 540 for 09:00 AM
    val endMinute: Int,   // e.g. 660 for 11:00 AM
    val isFocusLocked: Boolean = true, // If true, phone restricts social media apps during this time
    val reminderEnabled: Boolean = true,
    val colorHex: String = "#00E5FF",
    val dayOfWeekMask: Int = 127, // All days (Mon=1, Tue=2, Wed=4, Thu=8, Fri=16, Sat=32, Sun=64)
    val isCompletedToday: Boolean = false,
    val lastCompletedDateEpochDay: Long = -1L,
    val orderIndex: Int = 0
) {
    val durationMinutes: Int
        get() = if (endMinute >= startMinute) endMinute - startMinute else (1440 - startMinute) + endMinute

    fun getFormattedStartTime(): String {
        val hour = startMinute / 60
        val minute = startMinute % 60
        val amPm = if (hour >= 12) "PM" else "AM"
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return String.format("%02d:%02d %s", displayHour, minute, amPm)
    }

    fun getFormattedEndTime(): String {
        val hour = endMinute / 60
        val minute = endMinute % 60
        val amPm = if (hour >= 12) "PM" else "AM"
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return String.format("%02d:%02d %s", displayHour, minute, amPm)
    }

    fun isCurrentlyActive(currentMinute: Int): Boolean {
        return if (endMinute >= startMinute) {
            currentMinute in startMinute until endMinute
        } else {
            // Spans midnight
            currentMinute >= startMinute || currentMinute < endMinute
        }
    }
}
