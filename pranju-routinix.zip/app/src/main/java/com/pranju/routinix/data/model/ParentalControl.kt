package com.pranju.routinix.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "parent_config")
data class ParentConfig(
    @PrimaryKey
    val id: Int = 1,
    val isParentModeEnabled: Boolean = false,
    val parentPin: String = "2026",
    val childName: String = "Samiul (Son)",
    val pairingCode: String = "ROUT-8492",
    val dailySocialLimitMinutes: Int = 30,
    val tamperLockEnabled: Boolean = true,
    val isRemoteDeviceLockedByParent: Boolean = false,
    val remoteLockMessage: String = "অভিভাবক কর্তৃক ডিভাইসটি লক করা হয়েছে। মনোযোগ দিয়ে পড়া শেষ করুন।",
    val remoteLockDurationMinutes: Int = 60,
    val remoteLockTimestamp: Long = 0L
)

@Entity(tableName = "app_usage_records")
data class AppUsageRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val appName: String,
    val category: String, // "SOCIAL_MEDIA", "STUDY_READING", "GAMING", "OTHER"
    val dateEpochDay: Long,
    val usageMinutes: Int,
    val blockedAttemptCount: Int = 0
)
