package com.pranju.routinix.ui.focus

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pranju.routinix.MainActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pranju.routinix.service.FocusLockManager
import com.pranju.routinix.ui.language.LanguageManager
import com.pranju.routinix.ui.language.LocalAppStrings
import com.pranju.routinix.ui.language.appStrings
import com.pranju.routinix.ui.theme.CrimsonGlow
import com.pranju.routinix.ui.theme.CrimsonLock
import com.pranju.routinix.ui.theme.DeepSpace
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.RoutinixTheme
import kotlinx.coroutines.delay
import kotlin.random.Random

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val blockedPackage = intent.getStringExtra(EXTRA_BLOCKED_PACKAGE) ?: "Social Media App"
        val routineTitle = intent.getStringExtra(EXTRA_ROUTINE_TITLE) ?: "Active Routine"
        LanguageManager.init(this)

        setContent {
            val currentLanguage by LanguageManager.currentLanguage.collectAsStateWithLifecycle()
            val strings = LanguageManager.getStrings(currentLanguage)
            androidx.compose.runtime.CompositionLocalProvider(LocalAppStrings provides strings) {
                RoutinixTheme(darkTheme = true) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = DeepSpace
                    ) {
                        LockScreenContent(
                            blockedPackage = blockedPackage,
                            routineTitle = routineTitle,
                            onReturnToFocus = {
                                val mainIntent = Intent(this@LockScreenActivity, MainActivity::class.java).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                                }
                                startActivity(mainIntent)
                                finish()
                            },
                            onEmergencyUnlockSuccess = {
                                finish()
                            }
                        )
                    }
                }
            }
        }
    }

    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "extra_blocked_pkg"
        const val EXTRA_ROUTINE_TITLE = "extra_routine_title"
    }
}

@Composable
fun LockScreenContent(
    blockedPackage: String,
    routineTitle: String,
    onReturnToFocus: () -> Unit,
    onEmergencyUnlockSuccess: () -> Unit
) {
    val strings = appStrings()
    var timeLeftMillis by remember {
        mutableLongStateOf(
            maxOf(0L, FocusLockManager.focusEndTimeMillis.value - System.currentTimeMillis())
        )
    }

    LaunchedEffect(Unit) {
        while (timeLeftMillis > 0) {
            delay(1000)
            timeLeftMillis = maxOf(0L, FocusLockManager.focusEndTimeMillis.value - System.currentTimeMillis())
        }
    }

    val remainingMinutes = (timeLeftMillis / 1000) / 60
    val remainingSeconds = (timeLeftMillis / 1000) % 60

    var showEmergencyDialog by remember { mutableStateOf(false) }
    var mathNum1 by remember { mutableStateOf(Random.nextInt(15, 49)) }
    var mathNum2 by remember { mutableStateOf(Random.nextInt(12, 38)) }
    var userAnswer by remember { mutableStateOf("") }
    var mathError by remember { mutableStateOf(false) }

    val remainingPasses = FocusLockManager.emergencyUnlocksRemaining.value

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1F0606),
                        DeepSpace,
                        Color(0xFF070B14)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Pulsing Lock Icon
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(CrimsonGlow.copy(alpha = 0.5f))
                    .border(2.dp, CrimsonLock, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Monk Mode Locked",
                    tint = CrimsonLock,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            val isParentLock = FocusLockManager.isParentLockActive.value

            Text(
                text = if (isParentLock) strings.parentalLockTitle else strings.focusLockActiveTitle,
                style = MaterialTheme.typography.labelLarge,
                color = CrimsonLock,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isParentLock) strings.phoneLockedByParentTitle else strings.socialMediaBlockedTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isParentLock) FocusLockManager.parentLockMessage.value
                       else strings.lockdownMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = ElectricCyan,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Active Task Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = strings.currentRoutineTaskLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = routineTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F172A))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = String.format("%02d:%02d ${strings.remaining}", remainingMinutes, remainingSeconds),
                            style = MaterialTheme.typography.titleMedium,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Motivation Quote
            Text(
                text = strings.motivationQuote,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Primary Button: Return to Routine
            Button(
                onClick = onReturnToFocus,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("return_to_focus_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricCyan,
                    contentColor = Color(0xFF00363D)
                )
            ) {
                Text(
                    text = strings.returnToFocusBtn,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Emergency Unlock with Friction
            if (!showEmergencyDialog) {
                TextButton(
                    onClick = { showEmergencyDialog = true },
                    modifier = Modifier.testTag("emergency_unlock_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${strings.emergencyPassBtn} ($remainingPasses ${strings.leftPassesLabel})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                // Friction Math Challenge
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E131D)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonLock.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = strings.emergencyMathTitle,
                            style = MaterialTheme.typography.labelMedium,
                            color = CrimsonLock,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$mathNum1 + $mathNum2 = ?",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = userAnswer,
                            onValueChange = {
                                userAnswer = it
                                mathError = false
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            placeholder = { Text(strings.answerPlaceholder) },
                            isError = mathError,
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .testTag("emergency_math_input")
                        )
                        if (mathError) {
                            Text(
                                text = strings.incorrectAnswer,
                                color = CrimsonLock,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { showEmergencyDialog = false }
                            ) {
                                Text(strings.cancelBtn)
                            }
                            Button(
                                onClick = {
                                    val expected = mathNum1 + mathNum2
                                    if (userAnswer.trim().toIntOrNull() == expected) {
                                        val success = FocusLockManager.useEmergencyPass(3)
                                        if (success) {
                                            onEmergencyUnlockSuccess()
                                        }
                                    } else {
                                        mathError = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CrimsonLock),
                                modifier = Modifier.testTag("submit_math_unlock")
                            ) {
                                Text(strings.unlockMinsBtn)
                            }
                        }
                    }
                }
            }
        }
    }
}
