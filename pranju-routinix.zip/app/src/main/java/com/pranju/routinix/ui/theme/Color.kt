package com.pranju.routinix.ui.theme

import androidx.compose.ui.graphics.Color

// Routinix Dark & Cyber-Zen Focus Palette
val DeepSpace = Color(0xFF090D16)
val MidnightSurface = Color(0xFF111726)
val MidnightCard = Color(0xFF182238)
val MidnightBorder = Color(0xFF24324F)

val ElectricCyan = Color(0xFF00E5FF)
val CyanMuted = Color(0xFF0284C7)
val DeepIndigo = Color(0xFF6366F1)
val VioletGlow = Color(0xFF8B5CF6)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldDark = Color(0xFF065F46)
val AmberWarning = Color(0xFFF59E0B)
val CrimsonLock = Color(0xFFEF4444)
val CrimsonGlow = Color(0xFF7F1D1D)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Material 3 Tokens
val PrimaryDark = ElectricCyan
val OnPrimaryDark = Color(0xFF00363D)
val PrimaryContainerDark = Color(0xFF004F59)
val OnPrimaryContainerDark = Color(0xFF9BF0FF)

val SecondaryDark = DeepIndigo
val OnSecondaryDark = Color(0xFFFFFFFF)
val SecondaryContainerDark = Color(0xFF373A85)
val OnSecondaryContainerDark = Color(0xFFE0E0FF)

val TertiaryDark = VioletGlow
val BackgroundDark = DeepSpace
val SurfaceDark = MidnightSurface
val SurfaceVariantDark = MidnightCard
