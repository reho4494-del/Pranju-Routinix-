package com.pranju.routinix.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "task_completion_logs")
data class TaskCompletionLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskId: Long,
    val taskTitle: String,
    val category: String,
    val dateEpochDay: Long, // LocalDate.toEpochDay()
    val scheduledStartMinute: Int,
    val scheduledEndMinute: Int,
    val actualCompletedTimestamp: Long,
    val status: String, // "ON_TIME", "DELAYED", "SKIPPED"
    val delayMinutes: Int = 0
)
