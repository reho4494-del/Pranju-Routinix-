package com.pranju.routinix.ui.routine

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pranju.routinix.ui.language.appStrings
import com.pranju.routinix.data.model.RoutineTask
import com.pranju.routinix.ui.theme.DeepSpace
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.EmeraldSuccess
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.TextMuted
import com.pranju.routinix.ui.theme.TextSecondary
import com.pranju.routinix.ui.theme.VioletGlow
import java.time.LocalTime

@Composable
fun RoutineScreen(
    tasks: List<RoutineTask>,
    onCompleteTask: (RoutineTask, Boolean) -> Unit,
    onUncompleteTask: (RoutineTask) -> Unit,
    onAddTask: (RoutineTask) -> Unit,
    onDeleteTask: (RoutineTask) -> Unit,
    onStartFocusForTask: (RoutineTask) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    val strings = appStrings()

    val completedCount = tasks.count { it.isCompletedToday }
    val totalCount = tasks.size
    val progressPercent = if (totalCount > 0) (completedCount * 100) / totalCount else 0

    val currentMinute = remember {
        val now = LocalTime.now()
        now.hour * 60 + now.minute
    }

    val activeCurrentTask = tasks.firstOrNull { it.isCurrentlyActive(currentMinute) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("routine_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with Daily Progress
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MidnightCard),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = strings.routineSchedule,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = strings.routineSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ElectricCyan
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ElectricCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "$progressPercent% ${strings.done}",
                                    color = ElectricCyan,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { if (totalCount > 0) completedCount / totalCount.toFloat() else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = ElectricCyan,
                            trackColor = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "$completedCount / $totalCount ${strings.finishedOf}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            if (progressPercent == 100 && totalCount > 0) {
                                Text(
                                    text = strings.perfectDay,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Current Active Task Callout (if active right now)
            if (activeCurrentTask != null && !activeCurrentTask.isCompletedToday) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2236)),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldSuccess)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = strings.happeningNow,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldSuccess,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = activeCurrentTask.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${activeCurrentTask.getFormattedStartTime()} - ${activeCurrentTask.getFormattedEndTime()}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ElectricCyan
                                )
                            }

                            Button(
                                onClick = { onStartFocusForTask(activeCurrentTask) },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("start_current_task_focus")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color(0xFF00363D),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strings.lockIn,
                                    color = Color(0xFF00363D),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }

            // Routine Timeline List
            items(tasks) { task ->
                RoutineTaskItem(
                    task = task,
                    onToggleComplete = { isChecked ->
                        if (isChecked) {
                            // If completed before scheduled end time, mark as On-Time!
                            val onTime = currentMinute <= (task.endMinute + 15)
                            onCompleteTask(task, onTime)
                        } else {
                            onUncompleteTask(task)
                        }
                    },
                    onStartFocus = { onStartFocusForTask(task) },
                    onDelete = { onDeleteTask(task) }
                )
            }

            // Bottom Spacing for FAB
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Add Routine FAB
        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = ElectricCyan,
            contentColor = Color(0xFF00363D),
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("add_routine_fab")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Routine Task")
        }
    }

    if (showAddDialog) {
        AddRoutineDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { newTask ->
                onAddTask(newTask)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun RoutineTaskItem(
    task: RoutineTask,
    onToggleComplete: (Boolean) -> Unit,
    onStartFocus: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompletedToday) Color(0xFF0D1422) else MidnightCard
        ),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (task.isCompletedToday) EmeraldSuccess.copy(alpha = 0.4f) else MidnightBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Checkbox
            Checkbox(
                checked = task.isCompletedToday,
                onCheckedChange = onToggleComplete,
                colors = CheckboxDefaults.colors(
                    checkedColor = EmeraldSuccess,
                    uncheckedColor = TextMuted
                ),
                modifier = Modifier.testTag("task_checkbox_${task.id}")
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Task Info
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (task.isCompletedToday) TextMuted else Color.White
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Time Range
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${task.getFormattedStartTime()} - ${task.getFormattedEndTime()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    // Category Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF1E293B))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = task.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            fontSize = 10.sp
                        )
                    }

                    // Focus Lock Badge
                    if (task.isFocusLocked) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Monk Mode Locked",
                            tint = Color(0xFFF43F5E),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }

            // Quick actions
            if (!task.isCompletedToday && task.isFocusLocked) {
                IconButton(
                    onClick = onStartFocus,
                    modifier = Modifier.testTag("lock_task_btn_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Start Focus",
                        tint = ElectricCyan
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun AddRoutineDialog(
    onDismiss: () -> Unit,
    onAdd: (RoutineTask) -> Unit
) {
    val strings = appStrings()
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Deep Work") }
    var startHour by remember { mutableIntStateOf(9) }
    var startMinuteVal by remember { mutableIntStateOf(0) }
    var durationMinutes by remember { mutableIntStateOf(60) }
    var isFocusLocked by remember { mutableStateOf(true) }
    var reminderEnabled by remember { mutableStateOf(true) }

    val categories = listOf(
        "Deep Work" to strings.catDeepWork,
        "Study" to strings.catStudy,
        "Exercise" to strings.catExercise,
        "Reading" to strings.catReading,
        "Health" to strings.catHealth,
        "Creative" to strings.catCreative
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MidnightCard),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = strings.addTaskDialogTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(strings.taskTitleLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_task_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = strings.categoryLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.chunked(3).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            row.forEach { (catKey, catLabel) ->
                                OutlinedButton(
                                    onClick = { category = catKey },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (category == catKey) ElectricCyan.copy(alpha = 0.2f) else Color.Transparent
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (category == catKey) ElectricCyan else MidnightBorder
                                    ),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = catLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (category == catKey) ElectricCyan else Color.White,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Start time & duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = strings.startHourLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (startHour > 0) startHour-- }) {
                                Text("-", color = ElectricCyan, style = MaterialTheme.typography.titleLarge)
                            }
                            Text(
                                text = String.format("%02d:00", startHour),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { if (startHour < 23) startHour++ }) {
                                Text("+", color = ElectricCyan, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                    }

                    Column {
                        Text(text = strings.durationLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (durationMinutes > 15) durationMinutes -= 15 }) {
                                Text("-", color = ElectricCyan, style = MaterialTheme.typography.titleLarge)
                            }
                            Text(
                                text = "${durationMinutes}m",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { if (durationMinutes < 300) durationMinutes += 15 }) {
                                Text("+", color = ElectricCyan, style = MaterialTheme.typography.titleLarge)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Distraction Lock Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = strings.blockSocialDuringTask,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = strings.blockSocialSub,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = isFocusLocked,
                        onCheckedChange = { isFocusLocked = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElectricCyan,
                            checkedTrackColor = ElectricCyan.copy(alpha = 0.5f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text(strings.cancelBtn)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val sMinute = startHour * 60 + startMinuteVal
                                val eMinute = sMinute + durationMinutes
                                onAdd(
                                    RoutineTask(
                                        title = title.trim(),
                                        description = description.trim(),
                                        category = category,
                                        startMinute = sMinute,
                                        endMinute = eMinute,
                                        isFocusLocked = isFocusLocked,
                                        reminderEnabled = reminderEnabled
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        modifier = Modifier.testTag("confirm_add_task_btn")
                    ) {
                        Text(strings.addTaskBtn, color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
