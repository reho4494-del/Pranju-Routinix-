package com.pranju.routinix.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.pranju.routinix.MainActivity
import com.pranju.routinix.R
import com.pranju.routinix.RoutinixApp
import com.pranju.routinix.ui.focus.LockScreenActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class RoutineFocusService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopFocusMonitoring()
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        startFocusMonitoring()
        return START_STICKY
    }

    private fun startFocusMonitoring() {
        monitorJob?.cancel()
        val app = application as RoutinixApp

        monitorJob = serviceScope.launch {
            while (isActive) {
                if (FocusLockManager.isCurrentlyLocked()) {
                    checkForegroundApp(app)
                } else if (!FocusLockManager.isFocusActive.value) {
                    // Session ended naturally
                    stopFocusMonitoring()
                    stopSelf()
                    break
                }
                delay(800)
            }
        }
    }

    private suspend fun checkForegroundApp(app: RoutinixApp) {
        if (!FocusLockManager.hasUsageStatsPermission(this)) return

        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return

        val endTime = System.currentTimeMillis()
        val startTime = endTime - 3000

        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        val event = UsageEvents.Event()
        var currentForegroundPackage: String? = null

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                currentForegroundPackage = event.packageName
            }
        }

        if (currentForegroundPackage != null && currentForegroundPackage != packageName) {
            // Check if this package is in blocked apps
            val blockedApps = app.repository.getActiveBlockedApps()
            val isBlocked = blockedApps.any { it.packageName == currentForegroundPackage }

            if (isBlocked) {
                // Intercept & display lockscreen
                val lockIntent = Intent(this, LockScreenActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra(LockScreenActivity.EXTRA_BLOCKED_PACKAGE, currentForegroundPackage)
                    putExtra(
                        LockScreenActivity.EXTRA_ROUTINE_TITLE,
                        FocusLockManager.activeTaskTitle.value ?: "Routine Focus Block"
                    )
                }
                startActivity(lockIntent)
            }
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val taskTitle = FocusLockManager.activeTaskTitle.value ?: "Active Routine"

        return NotificationCompat.Builder(this, RoutinixApp.CHANNEL_FOCUS_LOCK)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("🛡️ Monk Focus Active: $taskTitle")
            .setContentText("Social media & distractions are blocked until routine finishes.")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun stopFocusMonitoring() {
        monitorJob?.cancel()
        FocusLockManager.setDndMode(this, false)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        const val NOTIFICATION_ID = 2001
        const val ACTION_START = "com.pranju.routinix.service.START_FOCUS"
        const val ACTION_STOP = "com.pranju.routinix.service.STOP_FOCUS"

        fun startService(context: Context) {
            val intent = Intent(context, RoutineFocusService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, RoutineFocusService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
