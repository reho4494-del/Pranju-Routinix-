package com.pranju.routinix.ui.analytics

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pranju.routinix.ui.language.appStrings
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.EmeraldSuccess
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.TextMuted
import com.pranju.routinix.ui.theme.TextSecondary
import com.pranju.routinix.ui.theme.VioletGlow

@Composable
fun DailyCompletionBarChart(
    dailyData: List<DailyRateData>,
    modifier: Modifier = Modifier
) {
    val strings = appStrings()
    val animationProgress = remember { Animatable(0f) }

    LaunchedEffect(dailyData) {
        animationProgress.snapTo(0f)
        animationProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 700)
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.dailyChartTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = strings.dailyChartSub,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Complete %", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height - 35f // leave room for bottom labels
                    val count = if (dailyData.isNotEmpty()) dailyData.size else 1
                    val barWidth = (width / count) * 0.45f
                    val spacing = width / count

                    // Draw reference gridlines at 25%, 50%, 75%, 100%
                    val gridLines = listOf(0.25f, 0.5f, 0.75f, 1f)
                    for (ratio in gridLines) {
                        val y = height * (1f - ratio)
                        drawLine(
                            color = MidnightBorder.copy(alpha = 0.6f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1f
                        )
                    }

                    dailyData.forEachIndexed { index, item ->
                        val centerX = (index * spacing) + (spacing / 2)
                        val barHeight = (item.ratePercent / 100f) * height * animationProgress.value
                        val barTop = height - barHeight
                        val left = centerX - (barWidth / 2)

                        // Draw background track
                        drawRoundRect(
                            color = Color(0xFF1E293B).copy(alpha = 0.5f),
                            topLeft = Offset(left, 0f),
                            size = Size(barWidth, height),
                            cornerRadius = CornerRadius(6f, 6f)
                        )

                        // Draw animated fill bar
                        val gradient = Brush.verticalGradient(
                            colors = if (item.ratePercent >= 80) {
                                listOf(ElectricCyan, Color(0xFF0284C7))
                            } else if (item.ratePercent >= 50) {
                                listOf(Color(0xFF38BDF8), Color(0xFF1D4ED8))
                            } else {
                                listOf(Color(0xFFF59E0B), Color(0xFFB45309))
                            },
                            startY = barTop,
                            endY = height
                        )

                        drawRoundRect(
                            brush = gradient,
                            topLeft = Offset(left, barTop),
                            size = Size(barWidth, maxOf(4f, barHeight)),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                }

                // Bottom Labels (Days & % numbers)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    dailyData.forEach { item ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${item.ratePercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (item.ratePercent >= 80) ElectricCyan else TextSecondary,
                                fontSize = 10.sp
                            )
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeeklyTrendLineChart(
    weeklyData: List<WeeklyRateData>,
    modifier: Modifier = Modifier
) {
    val strings = appStrings()
    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(weeklyData) {
        animProgress.snapTo(0f)
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 800)
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = strings.weeklyChartTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = strings.weeklyChartSub,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(18.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height - 30f
                    if (weeklyData.size < 2) return@Canvas

                    val spacing = width / (weeklyData.size - 1)
                    val points = weeklyData.mapIndexed { index, item ->
                        val x = index * spacing
                        val y = height * (1f - (item.ratePercent / 100f) * animProgress.value)
                        Offset(x, y)
                    }

                    // Fill under line
                    val fillPath = Path().apply {
                        moveTo(points.first().x, height)
                        points.forEach { lineTo(it.x, it.y) }
                        lineTo(points.last().x, height)
                        close()
                    }

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                VioletGlow.copy(alpha = 0.35f),
                                Color.Transparent
                            ),
                            startY = 0f,
                            endY = height
                        )
                    )

                    // Line Path
                    val linePath = Path().apply {
                        moveTo(points.first().x, points.first().y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }

                    drawPath(
                        path = linePath,
                        color = VioletGlow,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Points
                    points.forEachIndexed { idx, pt ->
                        drawCircle(
                            color = Color(0xFF0F172A),
                            radius = 6.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = if (weeklyData[idx].ratePercent >= 85) EmeraldSuccess else VioletGlow,
                            radius = 4.dp.toPx(),
                            center = pt
                        )
                    }
                }

                // Labels
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    weeklyData.forEach { item ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${item.ratePercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = VioletGlow,
                                fontSize = 10.sp
                            )
                            Text(
                                text = item.weekLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthlyRateBarChart(
    monthlyData: List<MonthlyRateData>,
    modifier: Modifier = Modifier
) {
    val strings = appStrings()
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightCard),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = strings.monthlyChartTitle,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = strings.monthlyChartSub,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(16.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                monthlyData.forEach { item ->
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = item.monthLabel,
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${item.ratePercent}% (${item.completedCount}/${item.totalCount} tasks)",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (item.ratePercent >= 80) EmeraldSuccess else ElectricCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF1E293B))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(fraction = (item.ratePercent / 100f).coerceIn(0f, 1f))
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(EmeraldSuccess, ElectricCyan)
                                        )
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}
