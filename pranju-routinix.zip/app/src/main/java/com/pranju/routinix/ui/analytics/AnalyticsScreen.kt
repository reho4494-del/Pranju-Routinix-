package com.pranju.routinix.ui.analytics

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pranju.routinix.ui.language.appStrings
import com.pranju.routinix.ui.theme.AmberWarning
import com.pranju.routinix.ui.theme.CrimsonLock
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.EmeraldSuccess
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.TextMuted
import com.pranju.routinix.ui.theme.TextSecondary
import com.pranju.routinix.ui.theme.VioletGlow

@Composable
fun AnalyticsScreen(
    dailyRates: List<DailyRateData>,
    weeklyRates: List<WeeklyRateData>,
    monthlyRates: List<MonthlyRateData>,
    categoryInsights: List<CategoryInsight>,
    summary: OverallAnalyticsSummary,
    modifier: Modifier = Modifier
) {
    val strings = appStrings()
    var selectedTimeframe by remember { mutableStateOf("Daily") } // "Daily", "Weekly", "Monthly"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("analytics_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = strings.analyticsTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = strings.analyticsSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Summary Metric Tiles
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricSummaryTile(
                    title = strings.avgCompletion,
                    value = "${summary.overallCompletionRate}%",
                    subtitle = strings.allTimeRateLabel,
                    tint = ElectricCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricSummaryTile(
                    title = strings.activeStreak,
                    value = "${summary.currentStreak}d",
                    subtitle = "${strings.bestStreakLabel} ${summary.bestStreak}d",
                    tint = EmeraldSuccess,
                    modifier = Modifier.weight(1f)
                )
                MetricSummaryTile(
                    title = strings.tasksLogged,
                    value = "${summary.totalTasksLogged}",
                    subtitle = strings.trackedRoutinesLabel,
                    tint = VioletGlow,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // AI Smart Insight Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D33)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.smartInsightTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (summary.smartInsightMessage.isNotEmpty()) summary.smartInsightMessage else strings.smartInsightMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }

        // Timeframe Selector Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val chips = listOf(
                    "Daily" to strings.dailyChip,
                    "Weekly" to strings.weeklyChip,
                    "Monthly" to strings.monthlyChip
                )
                chips.forEach { (key, label) ->
                    FilterChip(
                        selected = selectedTimeframe == key,
                        onClick = { selectedTimeframe = key },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan,
                            selectedLabelColor = Color(0xFF00363D),
                            containerColor = MidnightCard,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedTimeframe == key,
                            borderColor = if (selectedTimeframe == key) ElectricCyan else MidnightBorder
                        ),
                        modifier = Modifier.testTag("timeframe_chip_$key")
                    )
                }
            }
        }

        // Charts based on timeframe
        item {
            when (selectedTimeframe) {
                "Daily" -> DailyCompletionBarChart(dailyData = dailyRates)
                "Weekly" -> WeeklyTrendLineChart(weeklyData = weeklyRates)
                "Monthly" -> MonthlyRateBarChart(monthlyData = monthlyRates)
            }
        }

        // Task Types Insights Header
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.taskTypeInsightsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = strings.taskTypeInsightsSub,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Category Insight Cards
        items(categoryInsights) { insight ->
            CategoryInsightCard(insight = insight)
        }

        // Extra spacing at bottom
        item {
            Spacer(modifier = Modifier.height(64.dp))
        }
    }
}

@Composable
fun MetricSummaryTile(
    title: String,
    value: String,
    subtitle: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightCard),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = tint
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun CategoryInsightCard(insight: CategoryInsight) {
    val strings = appStrings()
    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightCard),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (insight.isTopPerformer) EmeraldSuccess.copy(alpha = 0.5f)
            else if (insight.isMostDelayed) AmberWarning.copy(alpha = 0.5f)
            else MidnightBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = insight.category,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (insight.isTopPerformer) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(EmeraldSuccess.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = strings.mostConsistentBadge,
                                color = EmeraldSuccess,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else if (insight.isMostDelayed) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AmberWarning.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = strings.oftenDelayedBadge,
                                color = AmberWarning,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Text(
                    text = "${insight.onTimeRatePercent}% ${strings.onTimeLabel}",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (insight.onTimeRatePercent >= 80) EmeraldSuccess else if (insight.onTimeRatePercent >= 60) ElectricCyan else AmberWarning,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress bar breakdown
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF1E293B))
            ) {
                val onTimeFraction = (insight.onTimeRatePercent / 100f).coerceIn(0f, 1f)
                val delayFraction = 1f - onTimeFraction

                if (onTimeFraction > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction = onTimeFraction)
                            .height(8.dp)
                            .background(EmeraldSuccess)
                    )
                }
                if (delayFraction > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .background(AmberWarning)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Counts breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = EmeraldSuccess,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${insight.completedOnTime} ${strings.onTimeLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${insight.delayedCount} ${strings.delayedLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Text(
                    text = "${strings.totalLabel} ${insight.totalCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }

            if (insight.recommendation.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = insight.recommendation,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
