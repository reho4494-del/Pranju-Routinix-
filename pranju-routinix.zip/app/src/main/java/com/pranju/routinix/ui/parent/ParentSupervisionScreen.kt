package com.pranju.routinix.ui.parent

import android.content.Context
import android.content.Intent
import com.pranju.routinix.service.FocusLockManager
import com.pranju.routinix.service.RoutineFocusService
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhonelinkLock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pranju.routinix.ui.language.appStrings
import com.pranju.routinix.data.model.AppUsageRecord
import com.pranju.routinix.data.model.ParentConfig
import com.pranju.routinix.ui.theme.AmberWarning
import com.pranju.routinix.ui.theme.CrimsonLock
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.EmeraldSuccess
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.TextMuted
import com.pranju.routinix.ui.theme.TextSecondary
import com.pranju.routinix.ui.theme.VioletGlow

@Composable
fun ParentSupervisionScreen(
    parentConfig: ParentConfig?,
    usageRecords: List<AppUsageRecord>,
    onUpdateConfig: (ParentConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings = appStrings()
    val config = parentConfig ?: ParentConfig()

    var isUnlockedByPin by remember { mutableStateOf(!config.isParentModeEnabled) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var showPairDialog by remember { mutableStateOf(false) }

    val readingMinutes = usageRecords
        .filter { it.category == "STUDY_READING" }
        .sumOf { it.usageMinutes }

    val socialMinutes = usageRecords
        .filter { it.category == "SOCIAL_MEDIA" }
        .sumOf { it.usageMinutes }

    val totalBlockedAttempts = usageRecords.sumOf { it.blockedAttemptCount }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("parent_supervision_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        item {
            Column {
                Text(
                    text = strings.parentSupervision,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = strings.parentSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = ElectricCyan
                )
            }
        }

        // Child Linking & Pairing Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ElectricCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhonelinkLock,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${strings.monitoredChild} ${config.childName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "${strings.pairingCodeLabel} ${config.pairingCode}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { showPairDialog = true },
                            modifier = Modifier.testTag("view_pairing_code_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.pairCodeBtn, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F172A))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = strings.tamperProtectionTitle,
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = strings.tamperProtectionDesc,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = config.tamperLockEnabled,
                            onCheckedChange = { isChecked ->
                                onUpdateConfig(config.copy(tamperLockEnabled = isChecked))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = EmeraldSuccess,
                                checkedTrackColor = EmeraldSuccess.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("tamper_protection_switch")
                        )
                    }
                }
            }
        }

        // Remote Child Phone Lockdown Control
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (config.isRemoteDeviceLockedByParent) Color(0xFF2E0F16) else MidnightCard
                ),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (config.isRemoteDeviceLockedByParent) CrimsonLock else MidnightBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (config.isRemoteDeviceLockedByParent) CrimsonLock.copy(alpha = 0.2f)
                                        else AmberWarning.copy(alpha = 0.2f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (config.isRemoteDeviceLockedByParent) CrimsonLock else AmberWarning,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = strings.remoteLockTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (config.isRemoteDeviceLockedByParent) strings.remoteLockStatusActive else strings.remoteLockStatusInactive,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (config.isRemoteDeviceLockedByParent) CrimsonLock else TextSecondary
                                )
                            }
                        }

                        Switch(
                            checked = config.isRemoteDeviceLockedByParent,
                            onCheckedChange = { shouldLock ->
                                val updated = config.copy(
                                    isRemoteDeviceLockedByParent = shouldLock,
                                    remoteLockTimestamp = if (shouldLock) System.currentTimeMillis() else 0L
                                )
                                onUpdateConfig(updated)
                                FocusLockManager.setParentRemoteLock(
                                    locked = shouldLock,
                                    message = updated.remoteLockMessage,
                                    durationMinutes = updated.remoteLockDurationMinutes
                                )
                                if (shouldLock) {
                                    com.pranju.routinix.service.RoutineFocusService.startService(context)
                                } else {
                                    com.pranju.routinix.service.RoutineFocusService.stopService(context)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CrimsonLock,
                                checkedTrackColor = CrimsonLock.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("remote_child_lock_switch")
                        )
                    }

                    if (config.isRemoteDeviceLockedByParent) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1B070B))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = strings.remoteLockNotice,
                                style = MaterialTheme.typography.bodySmall,
                                color = CrimsonLock
                            )
                        }
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Book Reading Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D251D)),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.6f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.readingTime,
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        val hours = readingMinutes / 60
                        val mins = readingMinutes % 60
                        Text(
                            text = "${hours}h ${mins}m",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = strings.dailyReadingGoalMet,
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSuccess,
                            fontSize = 10.sp
                        )
                    }
                }

                // Social Media Wasted Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF261014)),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonLock.copy(alpha = 0.6f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = CrimsonLock,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.socialMediaTime,
                                style = MaterialTheme.typography.labelSmall,
                                color = CrimsonLock,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${socialMinutes} Mins",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$totalBlockedAttempts ${strings.blockedAttemptsCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrimsonLock,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Monk Lock Enforcement Alert Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D33)),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.monkShieldStatsTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = strings.monkShieldStatsDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // Detailed App-by-App Screen Time Records
        item {
            Text(
                text = strings.appScreenTimeBreakdown,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        items(usageRecords) { record ->
            val isStudy = record.category == "STUDY_READING"
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(14.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isStudy) EmeraldSuccess.copy(alpha = 0.2f)
                                    else CrimsonLock.copy(alpha = 0.2f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isStudy) Icons.Default.AutoStories else Icons.Default.Smartphone,
                                contentDescription = null,
                                tint = if (isStudy) EmeraldSuccess else CrimsonLock,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = record.appName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (isStudy) strings.educationalStudyLabel else strings.socialDistractionLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${record.usageMinutes}m",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isStudy) EmeraldSuccess else ElectricCyan
                        )
                        if (record.blockedAttemptCount > 0) {
                            Text(
                                text = "${record.blockedAttemptCount}x ${strings.timesBlockedLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrimsonLock,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Export & Share Daily Progress to Parent's Phone
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = strings.shareReportTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = strings.shareReportSub,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val report = buildString {
                                appendLine("📋 Routinix Daily Progress Report")
                                appendLine("👤 Student: ${config.childName}")
                                appendLine("━━━━━━━━━━━━━━━━━━━")
                                appendLine("📖 Book Reading & Study: ${readingMinutes / 60}h ${readingMinutes % 60}m")
                                appendLine("📱 Social Media Time: $socialMinutes mins")
                                appendLine("🚫 Monk Lock Interceptions: $totalBlockedAttempts times blocked")
                                appendLine("🎯 Status: Safe & Disciplined")
                                appendLine("━━━━━━━━━━━━━━━━━━━")
                                appendLine("Sent automatically from Routinix App")
                            }

                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, report)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Daily Report to Parents"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("share_parent_report_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = Color(0xFF00363D)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.shareReportBtn,
                            color = Color(0xFF00363D),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(64.dp))
        }
    }

    if (showPairDialog) {
        Dialog(onDismissRequest = { showPairDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = strings.pairChildPhoneTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = strings.pairChildPhoneDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, ElectricCyan, RoundedCornerShape(12.dp))
                            .padding(horizontal = 24.dp, vertical = 14.dp)
                    ) {
                        Text(
                            text = config.pairingCode,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = ElectricCyan,
                            letterSpacing = 4.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "${strings.masterPinLabel} ${config.parentPin}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberWarning
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showPairDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
                    ) {
                        Text(strings.done, color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
