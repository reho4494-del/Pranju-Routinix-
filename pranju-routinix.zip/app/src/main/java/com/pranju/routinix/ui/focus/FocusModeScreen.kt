package com.pranju.routinix.ui.focus

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pranju.routinix.R
import com.pranju.routinix.ui.language.appStrings
import com.pranju.routinix.data.model.BlockedAppConfig
import com.pranju.routinix.data.model.RoutineTask
import com.pranju.routinix.service.FocusLockManager
import com.pranju.routinix.service.RoutineFocusService
import com.pranju.routinix.ui.theme.CrimsonLock
import com.pranju.routinix.ui.theme.DeepSpace
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.EmeraldSuccess
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.TextMuted
import com.pranju.routinix.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun FocusModeScreen(
    blockedApps: List<BlockedAppConfig>,
    activeRoutineTasks: List<RoutineTask>,
    onToggleAppBlock: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val strings = appStrings()
    var isFocusActive by remember { mutableStateOf(FocusLockManager.isFocusActive.value) }
    var strictMode by remember { mutableStateOf(true) }
    var selectedRoutineTask by remember { mutableStateOf(activeRoutineTasks.firstOrNull()) }

    var hasUsageAccess by remember { mutableStateOf(FocusLockManager.hasUsageStatsPermission(context)) }
    var hasOverlay by remember { mutableStateOf(FocusLockManager.hasOverlayPermission(context)) }
    var hasDnd by remember { mutableStateOf(FocusLockManager.hasNotificationPolicyAccess(context)) }

    // Periodic check for permissions and countdown
    var timeLeftMillis by remember {
        mutableLongStateOf(
            maxOf(0L, FocusLockManager.focusEndTimeMillis.value - System.currentTimeMillis())
        )
    }

    LaunchedEffect(Unit) {
        while (true) {
            hasUsageAccess = FocusLockManager.hasUsageStatsPermission(context)
            hasOverlay = FocusLockManager.hasOverlayPermission(context)
            hasDnd = FocusLockManager.hasNotificationPolicyAccess(context)
            isFocusActive = FocusLockManager.isCurrentlyLocked()
            if (isFocusActive) {
                timeLeftMillis = maxOf(0L, FocusLockManager.focusEndTimeMillis.value - System.currentTimeMillis())
            }
            delay(1000)
        }
    }

    val remainingMinutes = (timeLeftMillis / 1000) / 60
    val remainingSeconds = (timeLeftMillis / 1000) % 60

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("focus_mode_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card with Generated Graphic
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_focus_hero),
                            contentDescription = "Monk Mode Focus Sanctuary",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, MidnightCard)
                                    )
                                )
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isFocusActive) CrimsonLock.copy(alpha = 0.9f)
                                    else EmeraldSuccess.copy(alpha = 0.9f)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isFocusActive) "🔒 ${strings.lockBadge}" else strings.monkReady,
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = strings.strictBlocker,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.strictBlockerSub,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ElectricCyan
                        )
                    }
                }
            }
        }

        // Active Focus Status Banner / Controller
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isFocusActive) Color(0xFF1F0D16) else MidnightCard
                ),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isFocusActive) CrimsonLock else MidnightBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isFocusActive) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = CrimsonLock,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = strings.monkFocusActive,
                            style = MaterialTheme.typography.labelMedium,
                            color = CrimsonLock,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = FocusLockManager.activeTaskTitle.value ?: strings.startRoutineBlock,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = String.format("%02d:%02d ${strings.remaining}", remainingMinutes, remainingSeconds),
                            style = MaterialTheme.typography.headlineMedium,
                            color = ElectricCyan,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                FocusLockManager.stopFocusSession()
                                RoutineFocusService.stopService(context)
                                isFocusActive = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonLock),
                            modifier = Modifier.testTag("stop_focus_button")
                        ) {
                            Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.endFocus)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.startRoutineBlock,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = strings.startRoutineBlockSub,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Routine selector
                        if (activeRoutineTasks.isNotEmpty()) {
                            Text(
                                text = strings.selectRoutineToFocus,
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary,
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val current = selectedRoutineTask ?: activeRoutineTasks.first()
                                activeRoutineTasks.take(3).forEach { task ->
                                    val isSelected = current.id == task.id
                                    OutlinedButton(
                                        onClick = { selectedRoutineTask = task },
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (isSelected) ElectricCyan.copy(alpha = 0.2f) else Color.Transparent
                                        ),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelected) ElectricCyan else MidnightBorder
                                        ),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = task.title.take(12) + "..",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isSelected) ElectricCyan else Color.White,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        Button(
                            onClick = {
                                val task = selectedRoutineTask ?: activeRoutineTasks.firstOrNull()
                                val title = task?.title ?: "Deep Work Routine"
                                val duration = task?.durationMinutes ?: 45

                                FocusLockManager.startFocusSession(title, duration, strictMode)
                                if (hasDnd) {
                                    FocusLockManager.setDndMode(context, true)
                                }
                                RoutineFocusService.startService(context)
                                isFocusActive = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricCyan,
                                contentColor = Color(0xFF00363D)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("start_focus_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.enterMonkFocusNow,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Test Blocker Shield Button
                        OutlinedButton(
                            onClick = {
                                val lockIntent = Intent(context, LockScreenActivity::class.java).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    putExtra(LockScreenActivity.EXTRA_BLOCKED_PACKAGE, "com.instagram.android")
                                    putExtra(
                                        LockScreenActivity.EXTRA_ROUTINE_TITLE,
                                        selectedRoutineTask?.title ?: "Routine Block Test"
                                    )
                                }
                                context.startActivity(lockIntent)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_blocker_shield_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.previewLock, color = ElectricCyan)
                        }
                    }
                }
            }
        }

        // Permissions Status & Setup Guide
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = strings.permissionsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = strings.permissionsSub,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    PermissionItem(
                        title = strings.usageAccessTitle,
                        description = strings.usageAccessDesc,
                        isGranted = hasUsageAccess,
                        onGrantClick = { FocusLockManager.openUsageAccessSettings(context) }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PermissionItem(
                        title = strings.overlayTitle,
                        description = strings.overlayDesc,
                        isGranted = hasOverlay,
                        onGrantClick = { FocusLockManager.openOverlaySettings(context) }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    PermissionItem(
                        title = strings.dndTitle,
                        description = strings.dndDesc,
                        isGranted = hasDnd,
                        onGrantClick = { FocusLockManager.openNotificationPolicySettings(context) }
                    )
                }
            }
        }

        // Distracting Apps Selection List Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = strings.blockedAppsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${blockedApps.count { it.isBlocked }} ${strings.blockedAppsSub}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ElectricCyan
                    )
                }
            }
        }

        // Blocked App Items
        items(blockedApps) { app ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = app.appName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Text(
                            text = app.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    Switch(
                        checked = app.isBlocked,
                        onCheckedChange = { isChecked ->
                            onToggleAppBlock(app.packageName, isChecked)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElectricCyan,
                            checkedTrackColor = ElectricCyan.copy(alpha = 0.4f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("app_switch_${app.appName.lowercase().replace(" ", "_")}")
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(64.dp))
        }
    }
}

@Composable
fun PermissionItem(
    title: String,
    description: String,
    isGranted: Boolean,
    onGrantClick: () -> Unit
) {
    val strings = appStrings()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F172A))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGranted) EmeraldSuccess else CrimsonLock,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 11.sp
            )
        }

        if (!isGranted) {
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Text(
                    text = strings.grantBtn,
                    color = Color(0xFF00363D),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            Text(
                text = strings.activeStatus,
                color = EmeraldSuccess,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(end = 4.dp)
            )
        }
    }
}
