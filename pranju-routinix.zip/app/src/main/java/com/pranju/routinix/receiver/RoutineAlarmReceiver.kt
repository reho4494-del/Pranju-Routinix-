package com.pranju.routinix.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.pranju.routinix.MainActivity
import com.pranju.routinix.RoutinixApp

class RoutineAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskTitle = intent.getStringExtra(EXTRA_TASK_TITLE) ?: "Upcoming Routine Task"
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        val isFocusLocked = intent.getBooleanExtra(EXTRA_IS_FOCUS_LOCKED, true)

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_START_FOCUS_TASK_ID", taskId)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            taskId.toInt(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val lockNotice = if (isFocusLocked) "🔒 Distraction lock enabled until complete." else "Time to focus!"

        val notification = NotificationCompat.Builder(context, RoutinixApp.CHANNEL_ROUTINE_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("⏰ Routine Time: $taskTitle")
            .setContentText("Your scheduled routine block has started. $lockNotice")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify((3000 + taskId).toInt(), notification)
    }

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TASK_TITLE = "extra_task_title"
        const val EXTRA_IS_FOCUS_LOCKED = "extra_is_focus_locked"
    }
}
