package com.pranju.routinix.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "blocked_apps")
data class BlockedAppConfig(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val isBlocked: Boolean = true,
    val category: String = "Social Media" // "Social Media", "Video", "Gaming", "Other"
)
