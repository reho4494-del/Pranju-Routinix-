package com.pranju.routinix.ui.analytics

data class DailyRateData(
    val label: String,
    val dateEpochDay: Long,
    val completedCount: Int,
    val delayedCount: Int,
    val totalCount: Int,
    val ratePercent: Int
)

data class WeeklyRateData(
    val weekLabel: String,
    val completedCount: Int,
    val totalCount: Int,
    val ratePercent: Int
)

data class MonthlyRateData(
    val monthLabel: String,
    val completedCount: Int,
    val totalCount: Int,
    val ratePercent: Int
)

data class CategoryInsight(
    val category: String,
    val totalCount: Int,
    val completedOnTime: Int,
    val delayedCount: Int,
    val onTimeRatePercent: Int,
    val isTopPerformer: Boolean = false,
    val isMostDelayed: Boolean = false,
    val recommendation: String = ""
)

data class OverallAnalyticsSummary(
    val overallCompletionRate: Int,
    val totalTasksLogged: Int,
    val currentStreak: Int,
    val bestStreak: Int,
    val mostDisciplinedCategory: String,
    val mostDelayedCategory: String,
    val smartInsightMessage: String
)
