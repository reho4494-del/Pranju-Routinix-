package com.pranju.routinix.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.pranju.routinix.data.model.TaskCompletionLog
import kotlinx.coroutines.flow.Flow

@Dao
interface LogDao {
    @Query("SELECT * FROM task_completion_logs ORDER BY actualCompletedTimestamp DESC")
    fun getAllLogs(): Flow<List<TaskCompletionLog>>

    @Query("SELECT * FROM task_completion_logs WHERE dateEpochDay >= :startEpochDay AND dateEpochDay <= :endEpochDay ORDER BY dateEpochDay ASC")
    fun getLogsBetweenDates(startEpochDay: Long, endEpochDay: Long): Flow<List<TaskCompletionLog>>

    @Query("SELECT * FROM task_completion_logs WHERE dateEpochDay >= :startEpochDay")
    suspend fun getLogsSince(startEpochDay: Long): List<TaskCompletionLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TaskCompletionLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<TaskCompletionLog>)

    @Query("DELETE FROM task_completion_logs WHERE taskId = :taskId AND dateEpochDay = :epochDay")
    suspend fun deleteLogForTaskOnDay(taskId: Long, epochDay: Long)

    @Query("SELECT COUNT(*) FROM task_completion_logs")
    suspend fun getTotalLogCount(): Int
}
