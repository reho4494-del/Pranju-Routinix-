package com.pranju.routinix.data.repository

import com.pranju.routinix.data.local.BlockedAppDao
import com.pranju.routinix.data.local.GoalDao
import com.pranju.routinix.data.local.LogDao
import com.pranju.routinix.data.local.ParentalDao
import com.pranju.routinix.data.local.RoutineDao
import com.pranju.routinix.data.model.AppUsageRecord
import com.pranju.routinix.data.model.BlockedAppConfig
import com.pranju.routinix.data.model.Goal
import com.pranju.routinix.data.model.ParentConfig
import com.pranju.routinix.data.model.RoutineTask
import com.pranju.routinix.data.model.TaskCompletionLog
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class RoutineRepository(
    private val routineDao: RoutineDao,
    private val logDao: LogDao,
    private val goalDao: GoalDao,
    private val blockedAppDao: BlockedAppDao,
    private val parentalDao: ParentalDao
) {
    // Tasks
    val allTasks: Flow<List<RoutineTask>> = routineDao.getAllTasks()

    suspend fun insertTask(task: RoutineTask): Long = routineDao.insertTask(task)

    suspend fun updateTask(task: RoutineTask) = routineDao.updateTask(task)

    suspend fun deleteTask(task: RoutineTask) = routineDao.deleteTask(task)

    suspend fun completeTask(task: RoutineTask, onTime: Boolean, delayMinutes: Int = 0) {
        val todayEpochDay = LocalDate.now().toEpochDay()
        routineDao.setTaskCompletion(task.id, true, todayEpochDay)

        val log = TaskCompletionLog(
            taskId = task.id,
            taskTitle = task.title,
            category = task.category,
            dateEpochDay = todayEpochDay,
            scheduledStartMinute = task.startMinute,
            scheduledEndMinute = task.endMinute,
            actualCompletedTimestamp = System.currentTimeMillis(),
            status = if (onTime) "ON_TIME" else "DELAYED",
            delayMinutes = delayMinutes
        )
        logDao.insertLog(log)
    }

    suspend fun uncompleteTask(task: RoutineTask) {
        val todayEpochDay = LocalDate.now().toEpochDay()
        routineDao.setTaskCompletion(task.id, false, -1L)
        logDao.deleteLogForTaskOnDay(task.id, todayEpochDay)
    }

    suspend fun resetDayIfNeeded() {
        val todayEpochDay = LocalDate.now().toEpochDay()
        routineDao.resetCompletionForNewDay(todayEpochDay)
    }

    // Logs & Analytics
    val allLogs: Flow<List<TaskCompletionLog>> = logDao.getAllLogs()

    fun getLogsBetween(startEpochDay: Long, endEpochDay: Long): Flow<List<TaskCompletionLog>> =
        logDao.getLogsBetweenDates(startEpochDay, endEpochDay)

    suspend fun getLogsSince(startEpochDay: Long): List<TaskCompletionLog> =
        logDao.getLogsSince(startEpochDay)

    // Goals
    val activeGoals: Flow<List<Goal>> = goalDao.getActiveGoals()

    suspend fun insertGoal(goal: Goal): Long = goalDao.insertGoal(goal)

    suspend fun updateGoal(goal: Goal) = goalDao.updateGoal(goal)

    suspend fun deleteGoal(goal: Goal) = goalDao.deleteGoal(goal)

    // Blocked Apps
    val allBlockedApps: Flow<List<BlockedAppConfig>> = blockedAppDao.getAllBlockedApps()

    val activeBlockedAppsFlow: Flow<List<BlockedAppConfig>> = blockedAppDao.getActiveBlockedAppsFlow()

    suspend fun getActiveBlockedApps(): List<BlockedAppConfig> =
        blockedAppDao.getActiveBlockedApps()

    suspend fun setAppBlockedState(packageName: String, blocked: Boolean) =
        blockedAppDao.setAppBlockedState(packageName, blocked)

    suspend fun insertApps(apps: List<BlockedAppConfig>) =
        blockedAppDao.insertApps(apps)

    // Parental Controls & Child Screen Time Tracking
    val parentConfig: Flow<ParentConfig?> = parentalDao.getParentConfigFlow()

    suspend fun getParentConfig(): ParentConfig? = parentalDao.getParentConfig()

    suspend fun updateParentConfig(config: ParentConfig) =
        parentalDao.insertOrUpdateConfig(config)

    fun getTodayUsageRecords(): Flow<List<AppUsageRecord>> {
        val today = LocalDate.now().toEpochDay()
        return parentalDao.getUsageRecordsForDay(today)
    }

    suspend fun incrementBlockedAttempt(packageName: String) {
        val today = LocalDate.now().toEpochDay()
        parentalDao.incrementBlockedAttempt(packageName, today)
    }
}
