package com.pranju.routinix

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhonelinkLock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pranju.routinix.service.FocusLockManager
import com.pranju.routinix.service.RoutineFocusService
import com.pranju.routinix.ui.analytics.AnalyticsScreen
import com.pranju.routinix.ui.focus.FocusModeScreen
import com.pranju.routinix.ui.goals.GoalsScreen
import com.pranju.routinix.ui.parent.ParentSupervisionScreen
import com.pranju.routinix.ui.routine.RoutineScreen
import com.pranju.routinix.ui.theme.CrimsonLock
import com.pranju.routinix.ui.theme.DeepSpace
import com.pranju.routinix.ui.theme.ElectricCyan
import com.pranju.routinix.ui.theme.EmeraldSuccess
import com.pranju.routinix.ui.theme.MidnightBorder
import com.pranju.routinix.ui.theme.MidnightCard
import com.pranju.routinix.ui.theme.RoutinixTheme
import com.pranju.routinix.ui.theme.TextMuted
import com.pranju.routinix.ui.theme.TextSecondary
import com.pranju.routinix.ui.theme.VioletGlow
import com.pranju.routinix.viewmodel.RoutineViewModel

import com.pranju.routinix.ui.language.AppLanguage
import com.pranju.routinix.ui.language.LanguageManager
import com.pranju.routinix.ui.language.LocalAppStrings
import com.pranju.routinix.ui.language.appStrings
import androidx.compose.foundation.clickable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog

enum class RoutinixTab(val defaultTitle: String, val testTag: String) {
    ROUTINE("Routine", "tab_routine"),
    FOCUS("Monk Lock", "tab_focus"),
    ANALYTICS("Analytics", "tab_analytics"),
    SUPERVISION("Parent", "tab_supervision"),
    GOALS("Goals", "tab_goals")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        LanguageManager.init(this)

        val app = application as RoutinixApp

        setContent {
            val currentLanguage by LanguageManager.currentLanguage.collectAsStateWithLifecycle()
            val currentStrings = LanguageManager.getStrings(currentLanguage)

            CompositionLocalProvider(LocalAppStrings provides currentStrings) {
                RoutinixTheme(darkTheme = true) {
                    val viewModel: RoutineViewModel = viewModel(
                        factory = RoutineViewModel.Factory(app.repository)
                    )

                    RoutinixMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutinixMainScreen(viewModel: RoutineViewModel) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(RoutinixTab.ROUTINE) }
    var showLanguageDialog by remember { mutableStateOf(false) }

    val currentLanguage by LanguageManager.currentLanguage.collectAsStateWithLifecycle()
    val strings = appStrings()

    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val blockedApps by viewModel.blockedApps.collectAsStateWithLifecycle()
    val goals by viewModel.goals.collectAsStateWithLifecycle()
    val parentConfig by viewModel.parentConfig.collectAsStateWithLifecycle()
    val usageRecords by viewModel.todayUsageRecords.collectAsStateWithLifecycle()

    val dailyRates by viewModel.dailyRates.collectAsStateWithLifecycle()
    val weeklyRates by viewModel.weeklyRates.collectAsStateWithLifecycle()
    val monthlyRates by viewModel.monthlyRates.collectAsStateWithLifecycle()
    val categoryInsights by viewModel.categoryInsights.collectAsStateWithLifecycle()
    val summary by viewModel.summary.collectAsStateWithLifecycle()

    val isLockActive by FocusLockManager.isFocusActive.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(ElectricCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = strings.appName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = strings.tagline,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        // Language Switcher Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF182238))
                                .border(1.dp, MidnightBorder, RoundedCornerShape(8.dp))
                                .clickable { showLanguageDialog = true }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.testTag("language_switch_button")
                            ) {
                                Text(
                                    text = currentLanguage.flag,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentLanguage.nativeName,
                                    color = ElectricCyan,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.testTag("current_language_label")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Live Lock Badge
                        if (isLockActive) {
                            Box(
                                modifier = Modifier
                                    .padding(end = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CrimsonLock.copy(alpha = 0.2f))
                                    .border(1.dp, CrimsonLock, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(CrimsonLock)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "LOCK",
                                        color = CrimsonLock,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                },
                actions = {
                    androidx.compose.material3.IconButton(
                        onClick = { showLanguageDialog = true },
                        modifier = Modifier.testTag("open_language_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Language",
                            tint = ElectricCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpace
                ),
                windowInsets = WindowInsets.statusBars
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MidnightCard,
                contentColor = Color.White,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier
                    .border(
                        androidx.compose.foundation.BorderStroke(1.dp, MidnightBorder),
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            ) {
                NavigationBarItem(
                    selected = currentTab == RoutinixTab.ROUTINE,
                    onClick = { currentTab = RoutinixTab.ROUTINE },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = strings.tabRoutine,
                            tint = if (currentTab == RoutinixTab.ROUTINE) ElectricCyan else TextMuted
                        )
                    },
                    label = {
                        Text(
                            text = strings.tabRoutine,
                            color = if (currentTab == RoutinixTab.ROUTINE) ElectricCyan else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == RoutinixTab.ROUTINE) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = ElectricCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag(RoutinixTab.ROUTINE.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == RoutinixTab.FOCUS,
                    onClick = { currentTab = RoutinixTab.FOCUS },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = strings.tabFocus,
                            tint = if (currentTab == RoutinixTab.FOCUS) ElectricCyan else TextMuted
                        )
                    },
                    label = {
                        Text(
                            text = strings.tabFocus,
                            color = if (currentTab == RoutinixTab.FOCUS) ElectricCyan else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == RoutinixTab.FOCUS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = ElectricCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag(RoutinixTab.FOCUS.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == RoutinixTab.ANALYTICS,
                    onClick = { currentTab = RoutinixTab.ANALYTICS },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = strings.tabAnalytics,
                            tint = if (currentTab == RoutinixTab.ANALYTICS) ElectricCyan else TextMuted
                        )
                    },
                    label = {
                        Text(
                            text = strings.tabAnalytics,
                            color = if (currentTab == RoutinixTab.ANALYTICS) ElectricCyan else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == RoutinixTab.ANALYTICS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = ElectricCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag(RoutinixTab.ANALYTICS.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == RoutinixTab.SUPERVISION,
                    onClick = { currentTab = RoutinixTab.SUPERVISION },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.PhonelinkLock,
                            contentDescription = strings.tabParents,
                            tint = if (currentTab == RoutinixTab.SUPERVISION) ElectricCyan else TextMuted
                        )
                    },
                    label = {
                        Text(
                            text = strings.tabParents,
                            color = if (currentTab == RoutinixTab.SUPERVISION) ElectricCyan else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == RoutinixTab.SUPERVISION) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = ElectricCyan.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag(RoutinixTab.SUPERVISION.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == RoutinixTab.GOALS,
                    onClick = { currentTab = RoutinixTab.GOALS },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = strings.tabGoals,
                            tint = if (currentTab == RoutinixTab.GOALS) VioletGlow else TextMuted
                        )
                    },
                    label = {
                        Text(
                            text = strings.tabGoals,
                            color = if (currentTab == RoutinixTab.GOALS) VioletGlow else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (currentTab == RoutinixTab.GOALS) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = VioletGlow.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag(RoutinixTab.GOALS.testTag)
                )
            }
        },
        containerColor = DeepSpace
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = DeepSpace
        ) {
            when (currentTab) {
                RoutinixTab.ROUTINE -> {
                    RoutineScreen(
                        tasks = tasks,
                        onCompleteTask = { task, onTime -> viewModel.completeTask(task, onTime) },
                        onUncompleteTask = { task -> viewModel.uncompleteTask(task) },
                        onAddTask = { task -> viewModel.addTask(task) },
                        onDeleteTask = { task -> viewModel.deleteTask(task) },
                        onStartFocusForTask = { task ->
                            FocusLockManager.startFocusSession(
                                taskTitle = task.title,
                                durationMinutes = task.durationMinutes,
                                strictMode = true
                            )
                            RoutineFocusService.startService(context)
                            currentTab = RoutinixTab.FOCUS
                        }
                    )
                }

                RoutinixTab.FOCUS -> {
                    FocusModeScreen(
                        blockedApps = blockedApps,
                        activeRoutineTasks = tasks,
                        onToggleAppBlock = { pkg, isBlocked -> viewModel.toggleAppBlocked(pkg, isBlocked) }
                    )
                }

                RoutinixTab.ANALYTICS -> {
                    AnalyticsScreen(
                        dailyRates = dailyRates,
                        weeklyRates = weeklyRates,
                        monthlyRates = monthlyRates,
                        categoryInsights = categoryInsights,
                        summary = summary
                    )
                }

                RoutinixTab.SUPERVISION -> {
                    ParentSupervisionScreen(
                        parentConfig = parentConfig,
                        usageRecords = usageRecords,
                        onUpdateConfig = { cfg -> viewModel.updateParentConfig(cfg) }
                    )
                }

                RoutinixTab.GOALS -> {
                    GoalsScreen(
                        goals = goals,
                        onAddGoal = { goal -> viewModel.addGoal(goal) },
                        onDeleteGoal = { goal -> viewModel.deleteGoal(goal) }
                    )
                }
            }
        }
    }

    if (showLanguageDialog) {
        Dialog(onDismissRequest = { showLanguageDialog = false }) {
            androidx.compose.material3.Card(
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MidnightCard),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = strings.languageSelectTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    AppLanguage.values().forEach { lang ->
                        val isSelected = currentLanguage == lang
                        androidx.compose.material3.OutlinedButton(
                            onClick = {
                                LanguageManager.setLanguage(context, lang)
                                showLanguageDialog = false
                            },
                            colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isSelected) ElectricCyan.copy(alpha = 0.2f) else Color.Transparent
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) ElectricCyan else MidnightBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("select_language_${lang.code}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = lang.flag, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "${lang.nativeName} (${lang.displayName})",
                                        color = if (isSelected) ElectricCyan else Color.White,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 15.sp
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    TextButton(onClick = { showLanguageDialog = false }) {
                        Text(strings.closeBtn, color = TextSecondary)
                    }
                }
            }
        }
    }
}
