package com.pranju.routinix.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.pranju.routinix.data.model.AppUsageRecord
import com.pranju.routinix.data.model.ParentConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface ParentalDao {
    @Query("SELECT * FROM parent_config WHERE id = 1 LIMIT 1")
    fun getParentConfigFlow(): Flow<ParentConfig?>

    @Query("SELECT * FROM parent_config WHERE id = 1 LIMIT 1")
    suspend fun getParentConfig(): ParentConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConfig(config: ParentConfig)

    @Query("SELECT * FROM app_usage_records WHERE dateEpochDay = :epochDay ORDER BY usageMinutes DESC")
    fun getUsageRecordsForDay(epochDay: Long): Flow<List<AppUsageRecord>>

    @Query("SELECT * FROM app_usage_records WHERE dateEpochDay >= :startEpochDay AND dateEpochDay <= :endEpochDay")
    suspend fun getUsageBetween(startEpochDay: Long, endEpochDay: Long): List<AppUsageRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsageRecords(records: List<AppUsageRecord>)

    @Query("UPDATE app_usage_records SET blockedAttemptCount = blockedAttemptCount + 1 WHERE packageName = :packageName AND dateEpochDay = :epochDay")
    suspend fun incrementBlockedAttempt(packageName: String, epochDay: Long)
}
