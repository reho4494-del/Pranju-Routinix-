package com.pranju.routinix.service

import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object FocusLockManager {

    private val _isFocusActive = MutableStateFlow(false)
    val isFocusActive: StateFlow<Boolean> = _isFocusActive.asStateFlow()

    private val _activeTaskTitle = MutableStateFlow<String?>("Routine Deep Focus")
    val activeTaskTitle: StateFlow<String?> = _activeTaskTitle.asStateFlow()

    private val _focusEndTimeMillis = MutableStateFlow(0L)
    val focusEndTimeMillis: StateFlow<Long> = _focusEndTimeMillis.asStateFlow()

    private val _isStrictMode = MutableStateFlow(true)
    val isStrictMode: StateFlow<Boolean> = _isStrictMode.asStateFlow()

    private val _emergencyUnlocksRemaining = MutableStateFlow(3)
    val emergencyUnlocksRemaining: StateFlow<Int> = _emergencyUnlocksRemaining.asStateFlow()

    private val _tempUnlockedUntilMillis = MutableStateFlow(0L)
    val tempUnlockedUntilMillis: StateFlow<Long> = _tempUnlockedUntilMillis.asStateFlow()

    fun startFocusSession(
        taskTitle: String,
        durationMinutes: Int,
        strictMode: Boolean = true
    ) {
        val now = System.currentTimeMillis()
        _activeTaskTitle.value = taskTitle
        _focusEndTimeMillis.value = now + (durationMinutes * 60 * 1000L)
        _isStrictMode.value = strictMode
        _emergencyUnlocksRemaining.value = 3
        _tempUnlockedUntilMillis.value = 0L
        _isFocusActive.value = true
    }

    fun stopFocusSession() {
        _isFocusActive.value = false
        _focusEndTimeMillis.value = 0L
        _tempUnlockedUntilMillis.value = 0L
    }

    private val _isParentLockActive = MutableStateFlow(false)
    val isParentLockActive: StateFlow<Boolean> = _isParentLockActive.asStateFlow()

    private val _parentLockMessage = MutableStateFlow("অভিভাবক কর্তৃক ফোনটি লক করা হয়েছে।")
    val parentLockMessage: StateFlow<String> = _parentLockMessage.asStateFlow()

    fun setParentRemoteLock(
        locked: Boolean,
        message: String = "অভিভাবক কর্তৃক ফোনটি লক করা হয়েছে।",
        durationMinutes: Int = 60
    ) {
        _isParentLockActive.value = locked
        _parentLockMessage.value = message
        if (locked) {
            val now = System.currentTimeMillis()
            _activeTaskTitle.value = "Parent Remote Lockdown"
            _focusEndTimeMillis.value = now + (durationMinutes * 60 * 1000L)
            _isFocusActive.value = true
        } else {
            _isFocusActive.value = false
        }
    }

    fun isCurrentlyLocked(): Boolean {
        if (_isParentLockActive.value) return true
        if (!_isFocusActive.value) return false
        val now = System.currentTimeMillis()
        if (now >= _focusEndTimeMillis.value) {
            _isFocusActive.value = false
            return false
        }
        // If temporary 2-min grace unlock is active
        if (now < _tempUnlockedUntilMillis.value) {
            return false
        }
        return true
    }

    fun useEmergencyPass(minutes: Int = 3): Boolean {
        if (_emergencyUnlocksRemaining.value > 0) {
            _emergencyUnlocksRemaining.value -= 1
            _tempUnlockedUntilMillis.value = System.currentTimeMillis() + (minutes * 60 * 1000L)
            return true
        }
        return false
    }

    // Permission Checkers
    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun hasNotificationPolicyAccess(context: Context): Boolean {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return notificationManager.isNotificationPolicyAccessGranted
    }

    fun openUsageAccessSettings(context: Context) {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun openOverlaySettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun openNotificationPolicySettings(context: Context) {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun setDndMode(context: Context, enabled: Boolean) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (notificationManager.isNotificationPolicyAccessGranted) {
                if (enabled) {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                } else {
                    notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                }
            }
        } catch (_: Exception) {
            // Graceful fallback
        }
    }
}
