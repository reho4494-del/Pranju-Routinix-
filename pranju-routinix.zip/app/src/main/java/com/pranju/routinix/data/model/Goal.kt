package com.pranju.routinix.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "Productivity",
    val targetDaysPerWeek: Int = 6,
    val currentStreakDays: Int = 0,
    val bestStreakDays: Int = 0,
    val targetCompletionRatePercent: Int = 85,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false
)
