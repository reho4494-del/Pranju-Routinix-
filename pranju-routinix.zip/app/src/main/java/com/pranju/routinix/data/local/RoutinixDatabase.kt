package com.pranju.routinix.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.pranju.routinix.data.model.AppUsageRecord
import com.pranju.routinix.data.model.BlockedAppConfig
import com.pranju.routinix.data.model.Goal
import com.pranju.routinix.data.model.ParentConfig
import com.pranju.routinix.data.model.RoutineTask
import com.pranju.routinix.data.model.TaskCompletionLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(
    entities = [
        RoutineTask::class,
        TaskCompletionLog::class,
        Goal::class,
        BlockedAppConfig::class,
        ParentConfig::class,
        AppUsageRecord::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RoutinixDatabase : RoomDatabase() {
    abstract fun routineDao(): RoutineDao
    abstract fun logDao(): LogDao
    abstract fun goalDao(): GoalDao
    abstract fun blockedAppDao(): BlockedAppDao
    abstract fun parentalDao(): ParentalDao

    companion object {
        @Volatile
        private var INSTANCE: RoutinixDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): RoutinixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RoutinixDatabase::class.java,
                    "routinix_database"
                )
                    .addCallback(RoutinixDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class RoutinixDatabaseCallback(
        private val scope: CoroutineScope
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(database: RoutinixDatabase) {
            // Default Blocked Distraction Apps
            val defaultBlockedApps = listOf(
                BlockedAppConfig("com.facebook.katana", "Facebook", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.facebook.lite", "Facebook Lite", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.instagram.android", "Instagram", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.google.android.youtube", "YouTube", isBlocked = true, "Video"),
                BlockedAppConfig("com.zhiliaoapp.musically", "TikTok", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.twitter.android", "X (Twitter)", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.snapchat.android", "Snapchat", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.reddit.frontpage", "Reddit", isBlocked = true, "Social Media"),
                BlockedAppConfig("com.whatsapp", "WhatsApp", isBlocked = false, "Social Media"),
                BlockedAppConfig("org.telegram.messenger", "Telegram", isBlocked = false, "Social Media"),
                BlockedAppConfig("com.netflix.mediaclient", "Netflix", isBlocked = true, "Video"),
                BlockedAppConfig("com.dts.freefireth", "Free Fire", isBlocked = true, "Gaming")
            )
            database.blockedAppDao().insertApps(defaultBlockedApps)

            // Default Daily Routine Schedule (Monk Mode Discipline)
            val defaultTasks = listOf(
                RoutineTask(
                    title = "Morning Miracle & Mindset",
                    description = "Meditation, hydration, and goal setting",
                    category = "Health",
                    startMinute = 6 * 60,       // 06:00 AM
                    endMinute = 7 * 60,         // 07:00 AM
                    isFocusLocked = true,
                    colorHex = "#10B981"
                ),
                RoutineTask(
                    title = "Deep Study / High Focus Work Block 1",
                    description = "Zero distraction deep learning or coding session",
                    category = "Deep Work",
                    startMinute = 9 * 60,       // 09:00 AM
                    endMinute = 12 * 60,        // 12:00 PM
                    isFocusLocked = true,
                    colorHex = "#00E5FF"
                ),
                RoutineTask(
                    title = "Healthy Lunch & Mind Reset",
                    description = "Nutrition, light walk, no screens",
                    category = "Health",
                    startMinute = 12 * 60 + 30, // 12:30 PM
                    endMinute = 13 * 60 + 30,   // 01:30 PM
                    isFocusLocked = false,
                    colorHex = "#F59E0B"
                ),
                RoutineTask(
                    title = "Core Project Execution Block 2",
                    description = "Goal milestone work with Monk lock on social media",
                    category = "Study",
                    startMinute = 14 * 60,      // 02:00 PM
                    endMinute = 17 * 60,        // 05:00 PM
                    isFocusLocked = true,
                    colorHex = "#6366F1"
                ),
                RoutineTask(
                    title = "Physical Fitness & Workout",
                    description = "Cardio, weight training, or running",
                    category = "Exercise",
                    startMinute = 17 * 60 + 30, // 05:30 PM
                    endMinute = 18 * 60 + 45,   // 06:45 PM
                    isFocusLocked = true,
                    colorHex = "#EC4899"
                ),
                RoutineTask(
                    title = "Evening Reading & Day Reflection",
                    description = "Read 20 pages of self-development & log tomorrow's routine",
                    category = "Reading",
                    startMinute = 21 * 60,      // 09:00 PM
                    endMinute = 22 * 60,        // 10:00 PM
                    isFocusLocked = true,
                    colorHex = "#8B5CF6"
                )
            )
            database.routineDao().insertTasks(defaultTasks)

            // Default Goals for long term consistency
            val defaultGoals = listOf(
                Goal(
                    title = "Maintain 90% Routine Completion",
                    description = "Stick to schedule every single day without social distraction",
                    category = "Discipline",
                    targetDaysPerWeek = 6,
                    currentStreakDays = 5,
                    bestStreakDays = 14,
                    targetCompletionRatePercent = 90
                ),
                Goal(
                    title = "Zero Social Media During Study Hours",
                    description = "Keep phone locked with Monk focus mode during deep study",
                    category = "Focus",
                    targetDaysPerWeek = 7,
                    currentStreakDays = 8,
                    bestStreakDays = 21,
                    targetCompletionRatePercent = 95
                ),
                Goal(
                    title = "Daily Evening Reading",
                    description = "Read 20+ pages before bed every night",
                    category = "Knowledge",
                    targetDaysPerWeek = 5,
                    currentStreakDays = 3,
                    bestStreakDays = 9,
                    targetCompletionRatePercent = 80
                )
            )
            database.goalDao().insertGoals(defaultGoals)

            // Pre-seed some realistic historical completion logs for the last 14 days
            // so the user immediately sees rich, accurate Daily/Weekly/Monthly charts & Insights!
            val todayEpochDay = LocalDate.now().toEpochDay()
            val categories = listOf("Deep Work", "Study", "Exercise", "Reading", "Health", "Creative")
            val sampleLogs = mutableListOf<TaskCompletionLog>()

            for (dayOffset in 13 downTo 1) {
                val epochDay = todayEpochDay - dayOffset
                val nowMillis = System.currentTimeMillis() - (dayOffset * 86400000L)

                // Deep work usually completed on time (high performance)
                sampleLogs.add(
                    TaskCompletionLog(
                        taskId = 2,
                        taskTitle = "Deep Study / High Focus Work Block 1",
                        category = "Deep Work",
                        dateEpochDay = epochDay,
                        scheduledStartMinute = 540,
                        scheduledEndMinute = 720,
                        actualCompletedTimestamp = nowMillis + 720 * 60000L,
                        status = "ON_TIME",
                        delayMinutes = 0
                    )
                )

                // Study block occasionally delayed
                val isStudyDelayed = (dayOffset % 3 == 0)
                sampleLogs.add(
                    TaskCompletionLog(
                        taskId = 4,
                        taskTitle = "Core Project Execution Block 2",
                        category = "Study",
                        dateEpochDay = epochDay,
                        scheduledStartMinute = 840,
                        scheduledEndMinute = 1020,
                        actualCompletedTimestamp = nowMillis + 1040 * 60000L,
                        status = if (isStudyDelayed) "DELAYED" else "ON_TIME",
                        delayMinutes = if (isStudyDelayed) 25 else 0
                    )
                )

                // Exercise: frequently delayed if scheduled late, completed on other days
                val isExerciseDelayed = (dayOffset % 2 == 1)
                sampleLogs.add(
                    TaskCompletionLog(
                        taskId = 5,
                        taskTitle = "Physical Fitness & Workout",
                        category = "Exercise",
                        dateEpochDay = epochDay,
                        scheduledStartMinute = 1050,
                        scheduledEndMinute = 1125,
                        actualCompletedTimestamp = nowMillis + 1150 * 60000L,
                        status = if (isExerciseDelayed) "DELAYED" else "ON_TIME",
                        delayMinutes = if (isExerciseDelayed) 35 else 0
                    )
                )

                // Reading: consistently on time
                sampleLogs.add(
                    TaskCompletionLog(
                        taskId = 6,
                        taskTitle = "Evening Reading & Day Reflection",
                        category = "Reading",
                        dateEpochDay = epochDay,
                        scheduledStartMinute = 1260,
                        scheduledEndMinute = 1320,
                        actualCompletedTimestamp = nowMillis + 1320 * 60000L,
                        status = "ON_TIME",
                        delayMinutes = 0
                    )
                )
            }
            database.logDao().insertLogs(sampleLogs)

            // Initial Parental Control setup
            database.parentalDao().insertOrUpdateConfig(
                ParentConfig(
                    id = 1,
                    isParentModeEnabled = false,
                    parentPin = "2026",
                    childName = "Samiul (Son)",
                    pairingCode = "ROUT-8492",
                    dailySocialLimitMinutes = 30,
                    tamperLockEnabled = true
                )
            )

            // Initial App Usage Records for today
            val todayUsage = listOf(
                AppUsageRecord(
                    packageName = "com.google.android.youtube",
                    appName = "YouTube",
                    category = "SOCIAL_MEDIA",
                    dateEpochDay = todayEpochDay,
                    usageMinutes = 24,
                    blockedAttemptCount = 6
                ),
                AppUsageRecord(
                    packageName = "com.facebook.katana",
                    appName = "Facebook",
                    category = "SOCIAL_MEDIA",
                    dateEpochDay = todayEpochDay,
                    usageMinutes = 12,
                    blockedAttemptCount = 8
                ),
                AppUsageRecord(
                    packageName = "com.instagram.android",
                    appName = "Instagram",
                    category = "SOCIAL_MEDIA",
                    dateEpochDay = todayEpochDay,
                    usageMinutes = 9,
                    blockedAttemptCount = 14
                ),
                AppUsageRecord(
                    packageName = "com.google.android.apps.books",
                    appName = "Science & Math Book Reading",
                    category = "STUDY_READING",
                    dateEpochDay = todayEpochDay,
                    usageMinutes = 115,
                    blockedAttemptCount = 0
                ),
                AppUsageRecord(
                    packageName = "com.duolingo",
                    appName = "English & Literature Study",
                    category = "STUDY_READING",
                    dateEpochDay = todayEpochDay,
                    usageMinutes = 70,
                    blockedAttemptCount = 0
                )
            )
            database.parentalDao().insertUsageRecords(todayUsage)
        }
    }
}
