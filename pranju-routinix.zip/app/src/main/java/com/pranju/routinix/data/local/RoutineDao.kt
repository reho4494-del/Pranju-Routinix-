package com.pranju.routinix.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.pranju.routinix.data.model.RoutineTask
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutineDao {
    @Query("SELECT * FROM routine_tasks ORDER BY startMinute ASC")
    fun getAllTasks(): Flow<List<RoutineTask>>

    @Query("SELECT * FROM routine_tasks WHERE id = :id")
    suspend fun getTaskById(id: Long): RoutineTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: RoutineTask): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<RoutineTask>)

    @Update
    suspend fun updateTask(task: RoutineTask)

    @Delete
    suspend fun deleteTask(task: RoutineTask)

    @Query("DELETE FROM routine_tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    @Query("UPDATE routine_tasks SET isCompletedToday = :completed, lastCompletedDateEpochDay = :epochDay WHERE id = :id")
    suspend fun setTaskCompletion(id: Long, completed: Boolean, epochDay: Long)

    @Query("UPDATE routine_tasks SET isCompletedToday = 0 WHERE lastCompletedDateEpochDay != :currentEpochDay")
    suspend fun resetCompletionForNewDay(currentEpochDay: Long)
}
