package com.pranju.routinix

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.pranju.routinix.data.model.RoutineTask
import com.pranju.routinix.service.FocusLockManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Pranju Routinix", appName)
  }

  @Test
  fun `routine task duration and formatting`() {
    val task = RoutineTask(
        title = "Deep Study Block",
        category = "Study",
        startMinute = 9 * 60,  // 09:00 AM
        endMinute = 11 * 60 + 30 // 11:30 AM
    )
    assertEquals(150, task.durationMinutes)
    assertEquals("09:00 AM", task.getFormattedStartTime())
    assertEquals("11:30 AM", task.getFormattedEndTime())
    assertTrue(task.isCurrentlyActive(10 * 60))
    assertFalse(task.isCurrentlyActive(8 * 60))
  }

  @Test
  fun `focus lock manager session state`() {
    FocusLockManager.startFocusSession("Exam Focus", 45, true)
    assertTrue(FocusLockManager.isCurrentlyLocked())
    assertEquals("Exam Focus", FocusLockManager.activeTaskTitle.value)

    FocusLockManager.stopFocusSession()
    assertFalse(FocusLockManager.isCurrentlyLocked())
  }

  @Test
  fun `language manager switches correctly across all 4 languages`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    com.pranju.routinix.ui.language.LanguageManager.init(context)

    com.pranju.routinix.ui.language.LanguageManager.setLanguage(context, com.pranju.routinix.ui.language.AppLanguage.ENGLISH)
    assertEquals("Routine", com.pranju.routinix.ui.language.LanguageManager.strings.tabRoutine)
    assertEquals("Pranju Routinix", com.pranju.routinix.ui.language.LanguageManager.strings.appName)

    com.pranju.routinix.ui.language.LanguageManager.setLanguage(context, com.pranju.routinix.ui.language.AppLanguage.BANGLA)
    assertEquals("রুটিন", com.pranju.routinix.ui.language.LanguageManager.strings.tabRoutine)
    assertEquals("প্রাঞ্জু রুটিনিক্স", com.pranju.routinix.ui.language.LanguageManager.strings.appName)

    com.pranju.routinix.ui.language.LanguageManager.setLanguage(context, com.pranju.routinix.ui.language.AppLanguage.HINDI)
    assertEquals("रूटीन", com.pranju.routinix.ui.language.LanguageManager.strings.tabRoutine)
    assertEquals("प्रांजु रूटीनिक्स", com.pranju.routinix.ui.language.LanguageManager.strings.appName)

    com.pranju.routinix.ui.language.LanguageManager.setLanguage(context, com.pranju.routinix.ui.language.AppLanguage.NEPALI)
    assertEquals("रुटिन", com.pranju.routinix.ui.language.LanguageManager.strings.tabRoutine)
    assertEquals("प्राञ्जु रुटिनिक्स", com.pranju.routinix.ui.language.LanguageManager.strings.appName)
  }
}
