# Changelog - Pranju Routinix

All notable changes to this project are documented in this file.

## [1.0.0] - Commercial Production Release

### Features & Architecture
- **Daily Routine Scheduler & Tracker**:
  - Interactive recurring and scheduled daily tasks with category tagging (Deep Work, Study, Health, Creative).
  - Time tracking, streak counts, completion toggles, and overdue status calculations.
  - Alarm notifications using `AlarmManager` and `RoutineAlarmReceiver`.
- **Strict Monk Focus Mode & Distraction Blocker**:
  - Distraction-free countdown timer (Pomodoro & custom durations).
  - Background distraction monitoring via `RoutineFocusService` (Foreground Service).
  - Detection of blacklisted apps (Instagram, TikTok, YouTube, Games) using `UsageStatsManager`.
  - Full-screen `LockScreenActivity` overlay when attempted access to blocked apps occurs during active focus sessions.
- **Completion Analytics & Performance Dashboard**:
  - Daily, weekly, and monthly productivity rate curves.
  - Category completion breakdown insights and habit consistency tracking.
  - Fully reactive statistical calculations backed by local Room database aggregations.
- **Goal Setting & Milestone Tracking**:
  - Multi-horizon goal planning (Daily, Weekly, Monthly milestones).
  - Progress tracking, target counts, and completion archiving.
- **Parental Supervision & Remote Lock**:
  - Child device PIN authorization and supervisor pairing mode.
  - Strict remote/local focus lock enforcement with emergency passcode bypass.
- **Comprehensive Multi-Language Localization**:
  - Dynamic in-app language switching without activity restarts.
  - 4 languages supported out of the box:
    - English (Default)
    - Bengali (বাংলা)
    - Hindi (हिन्दी)
    - Nepali (नेपाली)
- **Local-First Architecture & Privacy**:
  - 100% offline-first storage via Android Jetpack Room Database (`RoutinixDatabase`).
  - No mandatory third-party accounts, external trackers, or telemetry.
  - Strict zero data leak design.
- **Commercial Package Cleanliness**:
  - Standardized package identifier: `com.pranju.routinix`.
  - Cleaned Gradle dependencies and removed unused Google Services / Firebase plugins.
  - Restored complete Gradle wrapper scripts (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`).
  - Custom Material 3 theme (`Theme.PranjuRoutinix`) with high-contrast Dark Mode palette.
