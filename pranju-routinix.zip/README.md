# Pranju Routinix - Commercial Android Source Code

**Pranju Routinix** is a modern, privacy-focused Android productivity application featuring daily routine tracking, monk-mode distraction blocking, completion analytics, multi-horizon goals, parental supervision lock, and dynamic multilingual localization.

Built with **100% Jetpack Compose**, **Kotlin Coroutines**, and **Android Room Database**, this project is architected with modern Clean/MVVM patterns and requires zero paid third-party APIs or subscription backends.

---

## 1. Project Overview & Specifications

| Parameter | Specification |
| :--- | :--- |
| **Application Name** | Pranju Routinix |
| **Application ID / Package** | `com.pranju.routinix` |
| **Architecture** | MVVM (Model-View-ViewModel) + Clean Architecture |
| **UI Framework** | 100% Jetpack Compose with Material Design 3 |
| **Local Database** | Room Database (SQLite) with KSP annotation processing |
| **Minimum SDK** | Android 7.0 (API level 24) |
| **Target SDK / Compile SDK** | Android 14+ (API level 36) |
| **JDK Requirement** | Java 17 or Java 21 |
| **Gradle Wrapper** | Gradle 9.3.1 |
| **Supported Languages** | English, Bengali (বাংলা), Hindi (हिन्दी), Nepali (नेपाली) |

---

## 2. Key Features

1. **Daily Routine Scheduling & Tracking**:
   - Create recurring and scheduled daily tasks with custom duration and category tags (*Deep Work*, *Study*, *Health*, *Creative*).
   - Real-time time counters, completion status toggling, and streak tracking.
   - Smart alarm reminders using `AlarmManager` and `RoutineAlarmReceiver`.

2. **Monk Focus Mode & Distraction Blocker**:
   - Strict countdown focus session timer with custom presets.
   - Background distraction monitor managed by `RoutineFocusService` (Foreground Service).
   - Detects blacklisted apps (Instagram, TikTok, YouTube, Games) via Android `UsageStatsManager`.
   - Full-screen lock overlay (`LockScreenActivity`) prevents access to distracting apps during active sessions.

3. **Productivity Analytics & Visual Dashboard**:
   - Daily, weekly, and monthly completion percentage curves.
   - Categorized time distribution and habit consistency summaries.
   - Room-backed reactive statistical aggregation with zero external analytics tracking.

4. **Goal Setting & Milestone Management**:
   - Multi-tier goals (Daily, Weekly, Monthly).
   - Milestone progress bars, target counters, and completed goal archiving.

5. **Parental Supervision & Remote Lock**:
   - PIN-protected supervisor authorization.
   - Supervised device pairing with emergency override passcode.

6. **Dynamic In-App Multilingual Engine**:
   - Instant in-app language switcher supporting English, Bengali, Hindi, and Nepali.
   - Switches language on-the-fly without restarting activities.

---

## 3. Technology Stack & Dependencies

- **Language:** Kotlin 2.2.10
- **UI:** Jetpack Compose (BOM 2024.09.00), Material Design 3, Extended Icons
- **Concurrency:** Kotlin Coroutines (`kotlinx-coroutines-android` 1.10.2)
- **Architecture:** AndroidX Lifecycle ViewModel & Compose runtime (`2.8.7`)
- **Data Persistence:** AndroidX Room (`2.7.0`) with KSP Compiler
- **Background Tasks:** Android Foreground Services, AlarmManager, BroadcastReceiver
- **Testing:** JUnit 4, Robolectric 4.16.1

---

## 4. Setup & Building the Project

### Prerequisites
- **Android Studio:** Ladybug (2024.2.1) or newer recommended.
- **JDK:** OpenJDK 17 or 21 configured in Android Studio (`Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK`).

### How to Open & Sync
1. Launch Android Studio.
2. Select **File > Open...** and navigate to the project root directory.
3. Allow Gradle to download dependencies and sync automatically.
4. If prompted to sync Gradle manually, click the **Sync Now** banner at the top right.

### Building via Command Line (Gradle Wrapper)
The project includes standard Gradle wrapper scripts (`gradlew` and `gradlew.bat`):

- **Build Debug APK:**
  ```bash
  ./gradlew assembleDebug
  ```
  Output located at: `app/build/outputs/apk/debug/app-debug.apk`

- **Build Release APK:**
  ```bash
  ./gradlew assembleRelease
  ```
  Output located at: `app/build/outputs/apk/release/app-release-unsigned.apk`

- **Generate Android App Bundle (AAB for Google Play):**
  ```bash
  ./gradlew bundleRelease
  ```
  Output located at: `app/build/outputs/bundle/release/app-release.aab`

- **Run Unit Tests:**
  ```bash
  ./gradlew testDebugUnitTest
  ```

---

## 5. Configuring Your Own Signing Key for Release

For security, the source code contains **no private keystores or signing passwords**.

To sign the release APK or AAB with your own developer certificate:

1. Generate a keystore in Android Studio:
   - Go to **Build > Generate Signed Bundle / APK...**
   - Select **Android App Bundle** or **APK**.
   - Click **Create new...** to create your `.jks` or `.keystore` file.
2. Alternatively, use standard command-line tools:
   ```bash
   keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-alias
   ```
3. Set your environment variables or configure your secure properties:
   ```bash
   export KEYSTORE_PATH="/path/to/release-key.jks"
   export STORE_PASSWORD="your-store-password"
   export KEY_PASSWORD="your-key-password"
   ```
4. Build the signed release:
   ```bash
   ./gradlew assembleRelease
   ```

---

## 6. Customization & Rebranding Guide

### How to Change the Application Name
1. Open `app/src/main/res/values/strings.xml`.
2. Update the string:
   ```xml
   <string name="app_name">Your Brand Name</string>
   ```
3. Update translations in `values-bn/strings.xml`, `values-hi/strings.xml`, and `values-ne/strings.xml` accordingly.
4. Update `settings.gradle.kts`:
   ```kotlin
   rootProject.name = "Your Brand Name"
   ```

### How to Change the Package Name / Application ID
1. Open `app/build.gradle.kts`.
2. Update `namespace` and `applicationId`:
   ```kotlin
   android {
       namespace = "com.yourcompany.appname"
       defaultConfig {
           applicationId = "com.yourcompany.appname"
           // ...
       }
   }
   ```
3. Rename the directory structure under `app/src/main/java/` to match your new package.

### How to Change the App Icon
1. In Android Studio, right-click `app/src/main/res` > **New > Image Asset**.
2. Select **Launcher Icons (Adaptive and Legacy)**.
3. Pick your brand asset and click **Finish**.

---

## 7. Android Permissions & Google Play Policy Disclosure

The application declares the following permissions in `AndroidManifest.xml`:

| Permission | Purpose | Google Play Review Notes |
| :--- | :--- | :--- |
| `POST_NOTIFICATIONS` | Alerts users when routine alarms fire or focus sessions end. | Standard runtime permission (Android 13+). |
| `VIBRATE` | Tactile feedback for alarms. | Normal install-time permission. |
| `FOREGROUND_SERVICE` | Maintains persistent countdown timer during active Monk Focus mode. | Required for continuous focus state. |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Used specifically for the strict distraction blocker service. | Declared with property `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` in manifest. When submitting to Google Play Console, enter: *"Monk focus countdown service that monitors and blocks distracting apps."* |
| `SYSTEM_ALERT_WINDOW` | Displays the full-screen lock overlay when a user opens a blacklisted app during focus mode. | System overlay permission (granted via Android Settings screen). |
| `PACKAGE_USAGE_STATS` | Detects foreground packages to determine when a user attempts to launch distracting social/game apps during an active focus lock. | Special App Access. In Google Play declaration form, categorize the app under **Productivity / Digital Wellbeing & Parental Controls**. |

---

## 8. Distribution & Commercial ZIP Preparation

When packaging this source code for commercial sale or delivery to buyers, exclude temporary and platform-specific build files to keep the ZIP archive small and clean:

**Files/Directories to Exclude:**
- `build/` and `app/build/` (clean build outputs)
- `.gradle/` (local daemon cache)
- `.idea/` and `*.iml` (IDE configuration)
- `debug.keystore` and `debug.keystore.base64`
- `metadata.json` (AI Studio container metadata)
- `.build-outputs/`

**Quick Command to Create Clean ZIP:**
```bash
./gradlew clean
zip -r Pranju_Routinix_Source_Code.zip . \
    -x "*.git*" \
    -x ".gradle/*" \
    -x "build/*" \
    -x "app/build/*" \
    -x ".idea/*" \
    -x "*.iml" \
    -x "debug.keystore*" \
    -x "metadata.json" \
    -x ".build-outputs/*"
```

---

## 9. Troubleshooting

- **Gradle Sync Fails:** Ensure your Android Studio Gradle JDK is set to Java 17 or Java 21 (`Settings > Build Tools > Gradle > Gradle JDK`).
- **Missing Keystore Warning on Release Build:** If you run `assembleRelease` without configuring environment variables, provide your signing keystore path via `KEYSTORE_PATH` or configure your signing credentials in `app/build.gradle.kts`.
- **Usage Stats Not Working on Emulator:** Open Android **Settings > Apps > Special app access > Usage access**, and toggle **Pranju Routinix** to Allowed.

---

## 10. License & Notices
- **Commercial Software License:** See `LICENSE.txt` for terms governing commercial rights and resale restrictions.
- **Third-Party Attributions:** See `NOTICE.txt` for open-source library licenses and attributions.
